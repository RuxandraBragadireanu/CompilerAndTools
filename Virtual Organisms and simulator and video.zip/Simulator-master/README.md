# Simulator

- Check the movie to see a compare between the static and dynamic simulation

- For 2D simulation: unzip the SeflAssemblingSimulator archieve  and check the manual inside to find out how to install and use the framework

- For 3D interactive simulation: unzip the VirtualOrganismsSimulator. While the code is cross-platform compatible, it is highly recommended in this version to use Visual Studio (any of the free editions) for browsing the source code and MS Windows 10 to execute it.

