1. AGAPIA systems
         A. Export compiler as DLL and let function calls from CPP code directly.
         B. Cross platform / CMAKE

2. AGAPIA API for implementing virtual organisms

3. Implement a smart home system (simulation) using AGAPIA 
     - What are the issues encountered ?
     - What would you change in the API to make it more usable ?

4. Implement a smart city system (simulation) using AGAPIA
     - Same questions as in 3

5. Graphical tool for modules composition 
     - Use a dummy library of modules 
     - Compose them graphically with arrows, etc.
     - Write an exporter to generate the AGAPIA code that is able to run the desired composition
