#pragma warning(push)
#pragma warning(disable: 4605)
#include "calc3.cpp"

#pragma warning(pop)
