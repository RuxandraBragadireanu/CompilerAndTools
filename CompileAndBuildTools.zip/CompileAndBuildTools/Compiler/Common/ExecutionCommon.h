// This header contains definitions necessary both in DLL generated and in 

#ifndef EXECUTION_COMMON_H
#define EXECUTION_COMMON_H

#include "AgapiaToCCode.h"
typedef std::map<std::string, AgapiaToCFunction> MapOfAgapiaToCFunctions;


#endif
