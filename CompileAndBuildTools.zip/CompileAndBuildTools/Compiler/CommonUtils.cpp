#include "CommonUtils.h"

void PutsEmpty(int iChars)
{
	for (int i = 0; i < iChars; i++)
		printf(" ");
}