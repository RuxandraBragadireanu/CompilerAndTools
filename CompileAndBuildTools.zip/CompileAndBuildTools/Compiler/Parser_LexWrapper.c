#pragma warning(push)
#pragma warning(disable: 4102)

#include "lex.yy.c"

#pragma warning(pop)
