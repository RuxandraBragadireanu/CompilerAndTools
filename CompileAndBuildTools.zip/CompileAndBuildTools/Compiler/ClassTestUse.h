#ifndef CLASS_TEST_USE
#define CLASS_TEST_USE

class TestClass
{
public:
	int a;
};

#endif