#ifndef COMMON_UTILS_H
#define COMMON_UTILS_H

#include <stdio.h>

// Prints iChars empty characters
void PutsEmpty(int iChars);

#endif