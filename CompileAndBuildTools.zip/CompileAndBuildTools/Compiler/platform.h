#pragma once
#ifndef PLATFORM_H
#define PLATFORM_H

#define PLATFORM_WINDOWS

#endif
