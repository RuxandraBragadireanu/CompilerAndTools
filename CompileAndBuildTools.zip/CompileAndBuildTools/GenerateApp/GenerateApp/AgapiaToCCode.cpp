#include "AgapiaToCCode.h"
 void InitializeAgapiaToCFunctions(){}